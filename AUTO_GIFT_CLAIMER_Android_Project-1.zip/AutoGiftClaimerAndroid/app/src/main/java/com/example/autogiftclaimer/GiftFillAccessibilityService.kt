package com.example.autogiftclaimer

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class GiftFillAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val prefs = getSharedPreferences("claimer", MODE_PRIVATE)
        if (!prefs.getBoolean("auto_fill", false)) return
        val code = prefs.getString("latest_code", null) ?: return
        val root = rootInActiveWindow ?: return
        val targets = ArrayList<AccessibilityNodeInfo>()
        collectEditable(root, targets)
        val target = targets.firstOrNull { node ->
            val hint = node.hintText?.toString()?.lowercase().orEmpty()
            val desc = node.contentDescription?.toString()?.lowercase().orEmpty()
            val text = node.text?.toString()?.lowercase().orEmpty()
            hint.contains("gift code") || hint.contains("gift") ||
                desc.contains("gift code") || text.contains("please enter gift code")
        } ?: targets.firstOrNull()
        if (target != null && target.text?.toString() != code) {
            target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val args = android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, code)
            }
            target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
        // Intentionally does not press Receive or submit anything.
    }

    private fun collectEditable(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        if (node.isEditable && node.isEnabled) out.add(node)
        for (i in 0 until node.childCount) node.getChild(i)?.let { collectEditable(it, out) }
    }

    override fun onInterrupt() {}
}
