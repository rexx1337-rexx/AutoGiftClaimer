package com.example.autogiftclaimer

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class MainActivity : Activity() {
    private val channel = "giftcodetest"
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private lateinit var status: TextView
    private lateinit var codeView: TextView
    private var latestCode: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("claimer", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 40, 28, 24)
        }
        val title = TextView(this).apply { text = "AUTO GIFT CLAIMER"; textSize = 24f; gravity = Gravity.CENTER }
        status = TextView(this).apply { text = "Channel: t.me/$channel"; textSize = 16f; gravity = Gravity.CENTER }
        codeView = TextView(this).apply { text = "Waiting for a 32-character code…"; textSize = 18f; gravity = Gravity.CENTER; setPadding(0, 30, 0, 30) }
        val check = Button(this).apply { text = "Check Telegram now"; setOnClickListener { fetchLatest() } }
        val copy = Button(this).apply { text = "Copy latest code"; setOnClickListener { copyCode() } }
        val enable = Button(this).apply {
            text = "Enable Auto Fill (Accessibility)"
            setOnClickListener {
                prefs.edit().putBoolean("auto_fill", true).apply()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                Toast.makeText(this@MainActivity, "Enable AUTO GIFT CLAIMER in Accessibility settings", Toast.LENGTH_LONG).show()
            }
        }
        val off = Button(this).apply { text = "Turn Auto Fill OFF"; setOnClickListener { prefs.edit().putBoolean("auto_fill", false).apply(); Toast.makeText(this@MainActivity, "Auto Fill OFF", Toast.LENGTH_SHORT).show() } }
        val open = Button(this).apply { text = "Open 91 Club"; setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://91club.com"))) } }
        listOf(title, status, codeView, check, copy, enable, off, open).forEach { layout.addView(it, LinearLayout.LayoutParams(-1, -2)) }
        setContentView(layout)
        fetchLatest()
        executor.scheduleAtFixedRate({ fetchLatest() }, 30, 30, TimeUnit.SECONDS)
    }

    private fun fetchLatest() {
        executor.execute {
            try {
                val conn = URL("https://t.me/s/$channel").openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 10000
                conn.setRequestProperty("User-Agent", "Mozilla/5.0")
                val html = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                // Telegram public preview is not guaranteed to expose every post.
                val matches = Pattern.compile("(?i)(?<![A-Z0-9])[A-F0-9]{32}(?![A-Z0-9])").matcher(html)
                var found: String? = null
                while (matches.find()) found = matches.group()
                runOnUiThread {
                    if (found != null) {
                        latestCode = found
                        getSharedPreferences("claimer", MODE_PRIVATE).edit().putString("latest_code", found).apply()
                        codeView.text = found
                        status.text = "Latest code found • auto-check every 30 sec"
                    } else {
                        status.text = "No 32-character hexadecimal code found. Try again later."
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Could not read channel. Check internet / channel visibility." }
            }
        }
    }

    private fun copyCode() {
        val code = latestCode ?: getSharedPreferences("claimer", MODE_PRIVATE).getString("latest_code", null)
        if (code == null) { Toast.makeText(this, "No code found yet", Toast.LENGTH_SHORT).show(); return }
        val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("Gift code", code))
        Toast.makeText(this, "Code copied", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() { super.onDestroy(); executor.shutdownNow() }
}
