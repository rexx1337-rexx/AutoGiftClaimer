# AUTO GIFT CLAIMER — Android source project

This is an Android Studio source project, **not a compiled/installable APK**.

## What it does
- Polls the public Telegram preview at `https://t.me/s/giftcodetest` every 30 seconds.
- Looks for a 32-character hexadecimal string (0–9, A–F).
- Stores the latest match and provides a Copy button.
- Optional Accessibility service can fill a visible editable field when Auto Fill is enabled.
- It deliberately never presses **Receive** or submits a claim.

## Important limitations
- This works only if Telegram exposes the public channel preview without login and the code is present in that HTML. Telegram may change or limit this page.
- The sample parser assumes codes are exactly 32 hexadecimal characters. If the real codes use other characters, adjust the regex in `MainActivity.kt`.
- Accessibility matching is best-effort. Some 91 Club pages/webviews may not expose the input field to Android accessibility, so manual paste may still be needed.
- The sample "Open 91 Club" URL is a placeholder. Replace it with the exact official URL/app used by the user.
- Do not enable accessibility for apps you do not trust. The service only fills a field and does not click Receive.

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Let Gradle sync and install Android SDK 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your Android phone.
5. In the app, tap Enable Auto Fill and enable AUTO GIFT CLAIMER under Android Accessibility settings.

This starter has not been compiled or tested against 91 Club. Verify the channel format and target page before relying on it.
